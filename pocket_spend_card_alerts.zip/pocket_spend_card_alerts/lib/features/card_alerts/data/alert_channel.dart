import 'dart:convert';

import 'package:flutter/services.dart';

/// A raw alert captured by the Android listener while the app may have been closed.
class QueuedAlert {
  final String body;
  final String sourcePackage;
  final DateTime postedAt;

  QueuedAlert(this.body, this.sourcePackage, this.postedAt);

  factory QueuedAlert.fromJson(Map<String, dynamic> j) => QueuedAlert(
        j['body'] as String,
        j['package'] as String? ?? '',
        DateTime.fromMillisecondsSinceEpoch((j['postedAt'] as num).toInt()),
      );
}

/// Bridge to the native AlertListenerService (Android only).
class AlertChannel {
  static const _channel = MethodChannel('pocket_spend/card_alerts');

  Future<bool> isAccessGranted() async =>
      await _channel.invokeMethod<bool>('isAccessGranted') ?? false;

  /// Opens the system "Notification access" screen. Show your own
  /// explanation screen BEFORE calling this (Play expects a clear disclosure).
  Future<void> openAccessSettings() => _channel.invokeMethod('openAccessSettings');

  /// Returns everything the listener queued and clears the native queue.
  Future<List<QueuedAlert>> drainQueue() async {
    final raw = await _channel.invokeMethod<String>('drainQueue') ?? '[]';
    final list = (jsonDecode(raw) as List).cast<Map<String, dynamic>>();
    return list.map(QueuedAlert.fromJson).toList()
      ..sort((a, b) => a.postedAt.compareTo(b.postedAt));
  }
}
