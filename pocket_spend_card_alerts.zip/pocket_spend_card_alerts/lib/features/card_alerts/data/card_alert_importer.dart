import 'package:hive/hive.dart';

import 'alert_channel.dart';
import 'alert_parser.dart';

/// What the importer hands to your existing transaction repository.
class AlertImportItem {
  final ParsedAlert? parsed; // null = no template matched (kept for later)
  final String rawBody;
  final DateTime postedAt; // real time of the transaction
  final String? suggestedCategory;
  final bool possibleMissedAlert;

  AlertImportItem({
    required this.parsed,
    required this.rawBody,
    required this.postedAt,
    this.suggestedCategory,
    this.possibleMissedAlert = false,
  });
}

/// Drains the native queue, parses, de-duplicates, and checks balance continuity.
///
/// Call [run] on app start and on AppLifecycleState.resumed.
class CardAlertImporter {
  final AlertChannel channel;
  final BankAlertParser parser;
  final Box<int> seenKeys; // dedupKey -> epoch ms first seen
  final Box<double> lastBalance; // "bank|acct" -> last known balance
  final Future<void> Function(AlertImportItem item) save;

  CardAlertImporter({
    required this.channel,
    required this.parser,
    required this.seenKeys,
    required this.lastBalance,
    required this.save,
  });

  Future<int> run() async {
    var imported = 0;
    for (final q in await channel.drainQueue()) {
      final parsed = parser.parse(q.body);

      if (parsed == null) {
        await save(AlertImportItem(parsed: null, rawBody: q.body, postedAt: q.postedAt));
        imported++;
        continue;
      }

      if (seenKeys.containsKey(parsed.dedupKey)) continue;
      await seenKeys.put(parsed.dedupKey, q.postedAt.millisecondsSinceEpoch);

      await save(AlertImportItem(
        parsed: parsed,
        rawBody: q.body,
        postedAt: q.postedAt,
        suggestedCategory: suggestCategory(parsed),
        possibleMissedAlert: await _checkBalance(parsed),
      ));
      imported++;
    }
    return imported;
  }

  /// If previous balance ± this amount doesn't equal the new balance,
  /// some transaction happened that we never saw an alert for.
  Future<bool> _checkBalance(ParsedAlert a) async {
    final bal = a.balanceAfter;
    if (bal == null) return false;
    final key = '${a.bankId}|${a.accountTail}';
    final prev = lastBalance.get(key);
    await lastBalance.put(key, bal);
    if (prev == null) return false;
    final expected = a.isDebit ? prev - a.amount : prev + a.amount;
    return (expected - bal).abs() > 0.005;
  }
}
