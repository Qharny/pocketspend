/// Parses bank alert text (SMS / banking-app notifications) into structured data.
///
/// Each bank gets its own [AlertTemplate]. Add a new template when you meet a
/// new format; unparsed messages are kept so they can be re-parsed later.
library;

class ParsedAlert {
  final String bankId;
  final String accountTail; // last visible digits only, e.g. "721"
  final bool isDebit;
  final String currency;
  final double amount;
  final DateTime date; // date only; the time comes from the notification
  final String channel; // e.g. "@BNK", "Tarkwa"
  final String info; // the bank's description, e.g. "Transfer Charges"
  final double? balanceAfter;

  const ParsedAlert({
    required this.bankId,
    required this.accountTail,
    required this.isDebit,
    required this.currency,
    required this.amount,
    required this.date,
    required this.channel,
    required this.info,
    this.balanceAfter,
  });

  /// Two notifications describing the same transaction produce the same key.
  ///
  /// The balance-after is what makes this safe: if you genuinely pay
  /// GHS 2.00 twice on the same day, the balance differs between the two
  /// alerts, so both are kept. If the SMS app and the bank app both show the
  /// same alert, everything matches and the copy is dropped.
  String get dedupKey => [
        bankId,
        accountTail,
        isDebit ? 'D' : 'C',
        amount.toStringAsFixed(2),
        '${date.year}-${date.month}-${date.day}',
        balanceAfter?.toStringAsFixed(2) ?? '-',
      ].join('|');
}

abstract class AlertTemplate {
  String get bankId;
  ParsedAlert? tryParse(String normalizedBody);
}

/// Format:
/// "A/C No.: 140*******721 has been debited with GHS 30.00 on 21 JUL 2026
///  Tarkwa. Info: CalPay MTN Pull Txn.. Avail. bal: GHS 10.43. Thank you."
class CalBankAccountTemplate implements AlertTemplate {
  @override
  final String bankId = 'calbank';

  static final _re = RegExp(
    r'A/C\s*No\.?\s*:?\s*(?<acct>[\d*Xx]+)\s+has\s+been\s+(?<dir>debited|credited)'
    r'\s+with\s+(?<cur>[A-Z]{3})\s*(?<amt>[\d,]+(?:\.\d{1,2})?)'
    r'\s+on\s+(?<date>\d{1,2}\s+[A-Za-z]{3}\s+\d{4})\s*(?<chan>[^.]*?)\.'
    r'\s*Info\s*:\s*(?<info>.*?)\.*\s*Avail\.?\s*bal\.?\s*:?\s*'
    r'(?<bcur>[A-Z]{3})\s*(?<bal>-?[\d,]+(?:\.\d{1,2})?)',
    caseSensitive: false,
  );

  @override
  ParsedAlert? tryParse(String body) {
    final m = _re.firstMatch(body);
    if (m == null) return null;
    final date = _parseDate(m.namedGroup('date')!);
    final amount = _money(m.namedGroup('amt')!);
    if (date == null || amount == null) return null;

    final acct = m.namedGroup('acct')!.replaceAll(RegExp(r'[^0-9]'), '');
    return ParsedAlert(
      bankId: bankId,
      // Keep only the trailing digits; never store the full number.
      accountTail: acct.length > 3 ? acct.substring(acct.length - 3) : acct,
      isDebit: m.namedGroup('dir')!.toLowerCase() == 'debited',
      currency: m.namedGroup('cur')!.toUpperCase(),
      amount: amount,
      date: date,
      channel: m.namedGroup('chan')!.trim(),
      info: m.namedGroup('info')!.trim(),
      balanceAfter: _money(m.namedGroup('bal')!),
    );
  }
}

class BankAlertParser {
  final List<AlertTemplate> templates;
  BankAlertParser({List<AlertTemplate>? templates})
      : templates = templates ?? [CalBankAccountTemplate()];

  ParsedAlert? parse(String raw) {
    final body = raw.replaceAll(RegExp(r'\s+'), ' ').trim();
    for (final t in templates) {
      final result = t.tryParse(body);
      if (result != null) return result;
    }
    return null;
  }
}

/// First-guess categories from the bank's "Info" text. The user's own tags
/// (merchant rules) should win over these once they exist.
class InfoRule {
  final RegExp pattern;
  final String category;
  const InfoRule(this.pattern, this.category);
}

final List<InfoRule> defaultInfoRules = [
  // Order matters: "Transfer Charges" is a fee, not a transfer.
  InfoRule(RegExp(r'charge|fee|levy|commission|sms alert', caseSensitive: false), 'Bank Fees'),
  InfoRule(RegExp(r'momo|mtn|telecel|vodafone|airteltigo|pull txn', caseSensitive: false), 'Transfer to MoMo'),
  InfoRule(RegExp(r'atm|cash withdrawal', caseSensitive: false), 'Cash'),
  InfoRule(RegExp(r'\bpos\b|purchase|merchant', caseSensitive: false), 'Shopping'),
  InfoRule(RegExp(r'salary|payroll', caseSensitive: false), 'Salary'),
];

String? suggestCategory(ParsedAlert a, [List<InfoRule>? rules]) {
  for (final r in rules ?? defaultInfoRules) {
    if (r.pattern.hasMatch(a.info)) return r.category;
  }
  return null;
}

const _months = {
  'JAN': 1, 'FEB': 2, 'MAR': 3, 'APR': 4, 'MAY': 5, 'JUN': 6,
  'JUL': 7, 'AUG': 8, 'SEP': 9, 'OCT': 10, 'NOV': 11, 'DEC': 12,
};

DateTime? _parseDate(String s) {
  final parts = s.trim().split(RegExp(r'\s+'));
  if (parts.length != 3) return null;
  final month = _months[parts[1].toUpperCase()];
  final day = int.tryParse(parts[0]);
  final year = int.tryParse(parts[2]);
  if (month == null || day == null || year == null) return null;
  return DateTime(year, month, day);
}

double? _money(String s) => double.tryParse(s.replaceAll(',', ''));
