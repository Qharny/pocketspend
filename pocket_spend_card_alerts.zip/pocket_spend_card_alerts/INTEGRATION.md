# Card alerts: integration notes

## 1. AndroidManifest.xml (inside `<manifest>` / `<application>`)

```xml
<uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>

<service
    android:name=".AlertListenerService"
    android:label="Pocket Spend spending alerts"
    android:exported="true"
    android:permission="android.permission.BIND_NOTIFICATION_LISTENER_SERVICE">
    <intent-filter>
        <action android:name="android.service.notification.NotificationListenerService"/>
    </intent-filter>
</service>
```

Change `com.example.pocket_spend` in both Kotlin files to your applicationId.
If your MainActivity already has code, merge the MethodChannel block into it.

## 2. Transaction model additions

Use the next free `@HiveField` indices after your existing ones (6+ assumed here).
Make them nullable or give defaults so existing data still loads.

```dart
@HiveField(6, defaultValue: 'manual') String source;      // 'manual' | 'cardAlert'
@HiveField(7, defaultValue: 'confirmed') String status;   // 'pending' | 'confirmed'
@HiveField(8) String? merchant;
@HiveField(9) String? accountTail;   // e.g. '721' only
@HiveField(10) String? bankInfo;     // "Transfer Charges", "CalPay MTN Pull Txn"
@HiveField(11) String? rawMessage;
@HiveField(12) double? balanceAfter;
@HiveField(13, defaultValue: false) bool possibleMissedAlert;
```

Re-run `build_runner` after editing.

## 3. Hive boxes

Open two extra boxes at startup: `Box<int>('alert_seen_keys')` and
`Box<double>('alert_last_balance')`. Since these hold bank data, open all
boxes with `HiveAesCipher`, key stored in `flutter_secure_storage`.

## 4. Wiring

- Call `CardAlertImporter.run()` on startup and on `AppLifecycleState.resumed`.
- In `save`, map `AlertImportItem` -> `Transaction(status: 'pending', source: 'cardAlert', ...)`,
  using `postedAt` for the date/time and `suggestedCategory` as the pre-selected category.
- Unparsed items (`parsed == null`) still save as pending with `rawMessage`,
  so the user can fill them manually and you can add a template later.
- Add categories used by the suggestions: Bank Fees, Transfer to MoMo, Cash, Salary.
