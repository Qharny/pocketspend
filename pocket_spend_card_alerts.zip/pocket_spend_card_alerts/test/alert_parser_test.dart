import 'package:flutter_test/flutter_test.dart';
import 'package:pocket_spend/features/card_alerts/data/alert_parser.dart';

void main() {
  final parser = BankAlertParser();

  const fee =
      'A/C No.: 140*******721 has been debited with GHS 2.00 on 21 OCT 2026 @BNK. Info: Transfer Charges. Avail. bal: GHS 268.42. Thank you.';
  const momo =
      'A/C No.: 140*******721 has been debited with GHS 30.00 on 21 JUL 2026  Tarkwa. Info: CalPay MTN Pull Txn.. Avail. bal: GHS 10.43. Thank you.';
  const credit =
      'A/C No.: 140*******721 has been credited with GHS 1,250.00 on 25 OCT 2026 @BNK. Info: Salary Oct. Avail. bal: GHS 1,518.42. Thank you.';

  test('parses transfer charge', () {
    final a = parser.parse(fee)!;
    expect(a.accountTail, '721');
    expect(a.isDebit, isTrue);
    expect(a.amount, 2.00);
    expect(a.date, DateTime(2026, 10, 21));
    expect(a.channel, '@BNK');
    expect(a.info, 'Transfer Charges');
    expect(a.balanceAfter, 268.42);
    expect(suggestCategory(a), 'Bank Fees');
  });

  test('parses MoMo pull with double dot and branch', () {
    final a = parser.parse(momo)!;
    expect(a.amount, 30.00);
    expect(a.channel, 'Tarkwa');
    expect(a.info, 'CalPay MTN Pull Txn');
    expect(a.balanceAfter, 10.43);
    expect(suggestCategory(a), 'Transfer to MoMo');
  });

  test('parses credits with thousands separators', () {
    final a = parser.parse(credit)!;
    expect(a.isDebit, isFalse);
    expect(a.amount, 1250.00);
    expect(a.balanceAfter, 1518.42);
  });

  test('identical alerts share a dedup key; different balance does not', () {
    final a = parser.parse(fee)!;
    final b = parser.parse(fee)!;
    final c = parser.parse(fee.replaceFirst('268.42', '266.42'))!;
    expect(a.dedupKey, b.dedupKey);
    expect(a.dedupKey, isNot(c.dedupKey));
  });

  test('ignores non-bank text', () {
    expect(parser.parse('Your OTP is 123456'), isNull);
  });
}
