package com.example.pocket_spend // <- change to your applicationId

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import org.json.JSONArray
import org.json.JSONObject

/**
 * Watches notifications from SMS / banking apps and queues bank alerts.
 * Runs even when the Flutter app is closed, so it never touches Hive:
 * it writes to a small native queue that Flutter drains on resume.
 */
class AlertListenerService : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return

        val text = extractText(n.extras) ?: return
        if (!looksLikeBankAlert(text)) return

        AlertQueue.append(
            this,
            JSONObject()
                .put("body", text)
                .put("package", sbn.packageName)
                .put("postedAt", sbn.postTime)
        )
        QuickTagNotifier.show(this, text)
    }

    /** SMS apps use MessagingStyle; others use big text / text. */
    private fun extractText(extras: Bundle): String? {
        @Suppress("DEPRECATION")
        val messages = extras.getParcelableArray(Notification.EXTRA_MESSAGES)
        val last = (messages?.lastOrNull() as? Bundle)?.getCharSequence("text")
        return (last
            ?: extras.getCharSequence(Notification.EXTRA_BIG_TEXT)
            ?: extras.getCharSequence(Notification.EXTRA_TEXT))?.toString()
    }

    private fun looksLikeBankAlert(t: String): Boolean {
        val s = t.lowercase()
        return ("has been debited" in s || "has been credited" in s) && "bal" in s
    }
}

object AlertQueue {
    private const val PREFS = "card_alert_queue"
    private const val KEY = "items"

    @Synchronized
    fun append(ctx: Context, item: JSONObject) {
        val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val arr = JSONArray(prefs.getString(KEY, "[]"))
        arr.put(item)
        prefs.edit().putString(KEY, arr.toString()).apply()
    }

    @Synchronized
    fun drain(ctx: Context): String {
        val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val out = prefs.getString(KEY, "[]") ?: "[]"
        prefs.edit().putString(KEY, "[]").apply()
        return out
    }
}

object QuickTagNotifier {
    private const val CHANNEL_ID = "card_alert_tagging"
    private val amountRe = Regex("""(debited|credited)\s+with\s+([A-Z]{3}\s*[\d,]+(?:\.\d{1,2})?)""", RegexOption.IGNORE_CASE)

    fun show(ctx: Context, body: String) {
        val m = amountRe.find(body) ?: return
        if (!m.groupValues[1].equals("debited", ignoreCase = true)) return // only prompt for spending
        val amount = m.groupValues[2]

        val mgr = ctx.getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            mgr.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Spending prompts", NotificationManager.IMPORTANCE_DEFAULT)
            )
        }

        val open = Intent(ctx, MainActivity::class.java)
            .putExtra("route", "needs_details")
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val pi = PendingIntent.getActivity(
            ctx, 0, open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notif = NotificationCompat.Builder(ctx, CHANNEL_ID)
            .setSmallIcon(ctx.applicationInfo.icon)
            .setContentTitle("You spent $amount")
            .setContentText("Tap to say what it was for")
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()

        // Requires POST_NOTIFICATIONS on Android 13+; silently skipped if denied.
        if (NotificationManagerCompat.from(ctx).areNotificationsEnabled()) {
            mgr.notify(System.currentTimeMillis().toInt(), notif)
        }
    }
}
